#!/bin/bash
# ─────────────────────────────────────────────────────────────────
#  services.sh  —  Automated sequential service calls
# ─────────────────────────────────────────────────────────────────

SESSION="arrobo_services"
WS="$HOME/arrobo_ws"
SRC="source /opt/ros/humble/setup.bash && source $WS/install/setup.bash"

if tmux has-session -d -t $SESSION 2>/dev/null; then
    echo "[services] Session '$SESSION' already open."
    exit 1
fi

# 1. Start session & run ak_60_up in the background window
tmux new-session -d -s $SESSION -n "ak_node" -x 240 -y 40
tmux send-keys -t $SESSION:0 "$SRC" Enter
tmux send-keys -t $SESSION:0 "ros2 run ak_pkg ak_60_up" Enter

# 2. Wait for 5 seconds
echo "[services] Launched ak_60_up. Waiting 5 seconds..."
sleep 5

# 3. Create the grid window for the service calls
tmux new-window -t $SESSION -n "service_calls"

# Build out Row 1 (Horizontal splits)
P_CLIMB=$(tmux display-message -p '#{pane_id}')
P_ROLL=$(tmux split-window -h -t $P_CLIMB -P -F '#{pane_id}')
P_ELEV_V=$(tmux split-window -h -t $P_ROLL -P -F '#{pane_id}')

tmux select-layout -t $SESSION:1 reorder-horizontal

# Build out Row 2 (Vertical splits)
P_ELEV_H=$(tmux split-window -v -t $P_CLIMB -P -F '#{pane_id}')
P_PITCH=$(tmux split-window -v -t $P_ROLL -P -F '#{pane_id}')
P_CATCH=$(tmux split-window -v -t $P_ELEV_V -P -F '#{pane_id}')

tmux select-layout -t $SESSION:1 tiled

# ─────────────────────────────────────────────────────────────────
#  SEQUENTIAL EXECUTION (UPDATED ORDER)
# ─────────────────────────────────────────────────────────────────
echo "[services] Firing ROS 2 service calls in priority order..."

# Step A: Run init_gripper_pitch first
tmux send-keys -t $P_PITCH "$SRC" Enter
tmux send-keys -t $P_PITCH "ros2 service call /init_gripper_pitch std_srvs/srv/SetBool \"{data: true}\"" Enter
sleep 0.5

# Step B: Run gripper_pitch_set immediately after
tmux send-keys -t $P_PITCH "ros2 service call /gripper_pitch_set motor_interfaces/srv/MotorState \"{data: true, state: 0.0}\"" Enter
sleep 0.5

Step C: Run everything else sequentially
Pane 0: init_climb
tmux send-keys -t $P_CLIMB "$SRC" Enter
tmux send-keys -t $P_CLIMB "ros2 service call /init_climb std_srvs/srv/SetBool \"{data: true}\"" Enter
sleep 0.5

# Pane 1: init_roll
tmux send-keys -t $P_ROLL "$SRC" Enter
tmux send-keys -t $P_ROLL "ros2 service call /init_roll motor_interfaces/srv/MotorState \"{data: true, state: 5.6}\"" Enter
sleep 0.5

# Pane 2: init_elev_vert
tmux send-keys -t $P_ELEV_V "$SRC" Enter
tmux send-keys -t $P_ELEV_V "ros2 service call /init_elev_vert std_srvs/srv/SetBool \"{data: true}\"" Enter
sleep 0.5

# Pane 3: init_elev_horiz
tmux send-keys -t $P_ELEV_H "$SRC" Enter
tmux send-keys -t $P_ELEV_H "ros2 service call /init_elev_horiz std_srvs/srv/SetBool \"{data: true}\"" Enter
sleep 0.5

# Pane 5: init_gripper_catch
tmux send-keys -t $P_CATCH "$SRC" Enter
tmux send-keys -t $P_CATCH "ros2 service call /init_gripper_catch std_srvs/srv/SetBool \"{data: true}\"" Enter

# Land UI focus back on the pitch pane to monitor the starting action
tmux select-window -t $SESSION:1
tmux select-pane -t $P_PITCH

# Attach to view logs
tmux attach-session -t $SESSION