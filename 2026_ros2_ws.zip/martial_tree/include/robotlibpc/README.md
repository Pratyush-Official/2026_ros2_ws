# Robot Libary for Personal Computer

- Used in `Rashberry PI`.
- Can be used directly using PC.
