#include "bt_main.hpp"

using namespace std::chrono_literals;

tree_ticker::tree_ticker(const std::string &node_name)
: rclcpp::Node(node_name)
{
    RCLCPP_INFO(get_logger(), "tree_ticker constructed");
}

void tree_ticker::setup()
{
    create_behavior_tree();
    timer_group = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    bool debug_mode = this->declare_parameter<bool>("debug", false);
    int tick_ms = debug_mode ? 2000 : 10;

    timer_ = create_wall_timer(
        std::chrono::milliseconds(tick_ms),
        std::bind(&tree_ticker::update_behavior_tree, this),
        timer_group
    );
}

void tree_ticker::create_behavior_tree()
{
    register_custom_action_nodes();
    // --- merged from bt.cpp ---
    register_condition_nodes();
    register_decision_nodes();
    register_actions_nodes();

    auto blackboard = BT::Blackboard::create();
    
    blackboard->set<int>("in_martial", 0);
    blackboard->set<int>("spear_assembled", 0);
    blackboard->set<int>("scroll_picked_from_entrance", 0);
    blackboard->set<int>("store",0);
    blackboard->set<int>("carry",0);
    blackboard->set<int>("climbed_three_photos", 0);

    blackboard->set<int>("in_forest", 0);
    blackboard->set<int>("photo_sequence", 0);

    blackboard->set<int>("in_arena",0);
    blackboard->set<int>("placed_1",0);
    blackboard->set<int>("placed_2",0);
    
    std_msgs::msg::Float32MultiArray arr;
    arr.data = {0.0f, 0.0f};
    // blackboard->set<std::vector<float>>("entrance_movement", std::vector<float>{140.0f, 1170.0f}); // The key that gets assigned to the actual client in xml

    blackboard->set<CurrentYaw>("current_yaw", CurrentYaw::FRONT);

    const std::string pkg = ament_index_cpp::get_package_share_directory("martial_tree");

    try {
        factory.registerBehaviorTreeFromFile(pkg + "/bt_xml/main_trees/climb_three_photos.xml");
        RCLCPP_INFO(get_logger(), "climb_three_photos OK");
        factory.registerBehaviorTreeFromFile(pkg + "/bt_xml/main_trees/spear_assembly.xml");
        RCLCPP_INFO(get_logger(), "spear_assembly OK");
        factory.registerBehaviorTreeFromFile(pkg + "/bt_xml/main_trees/main_bt.xml");
        RCLCPP_INFO(get_logger(), "test OK");
        factory.registerBehaviorTreeFromFile(pkg + "/bt_xml/main_trees/sick_scroll_pick_from_entrance.xml");
        RCLCPP_INFO(get_logger(), "sick_scroll_pick_from_entrance OK");
        factory.registerBehaviorTreeFromFile(pkg + "/bt_xml/main_trees/odom_scroll_pick_from_entrance.xml");
        RCLCPP_INFO(get_logger(), "odom_scroll_pick_from_entrance OK");

        tree_ = factory.createTree("MainTree", blackboard);
        RCLCPP_INFO(get_logger(), "tree created OK");

        logger_ = std::make_unique<BT::StdCoutLogger>(tree_);
        groot_publisher_ = std::make_unique<BT::Groot2Publisher>(tree_, 1667);
        file_logger_ = std::make_unique<BT::FileLogger2>(tree_, "/home/maomao/ROBOCON_26/2026_ros2_ws/src/martial_tree/bt_xml/bt_trace.btlog");

    } catch (const std::exception &e) {
        RCLCPP_ERROR(get_logger(), "BT error: %s", e.what());
        throw;
    }

    std::string home = std::getenv("HOME");
    std::ofstream out(home + "/ROBOCON_26/2026_ros2_ws/src/martial_tree/bt_xml/bt_node_models.xml");
    out << BT::writeTreeNodesModelXML(factory);
    out.close();
}

void tree_ticker::register_custom_action_nodes()
{
    auto shared_self = std::static_pointer_cast<tree_ticker>(this->shared_from_this());

    factory.registerBuilder<SickPIDClient>(
        "SickPIDClient",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<SickPIDClient>(name, config, shared_self); }
    );

    factory.registerBuilder<GoToEntrance>(
        "GoToEntrance",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<GoToEntrance>(name, config, shared_self); }
    );

    factory.registerBuilder<YawPIDClient>(
        "YawPIDClient",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<YawPIDClient>(name, config, shared_self); }
    );

    factory.registerBuilder<AkClient>(
        "AkClient",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<AkClient>(name, config, shared_self); }
    );

    factory.registerBuilder<YawSetpoint>(
        "YawSetpoint",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<YawSetpoint>(name, config, shared_self); }
    );

    factory.registerBuilder<GetROIDetections>(
        "GetROIDetections",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<GetROIDetections>(name, config, shared_self); }
    );

    factory.registerBuilder<FindHiddenScroll>(
        "FindHiddenScroll",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<FindHiddenScroll>(name, config); }
    );

    factory.registerBuilder<OdomPIDClient>(
        "OdomPIDClient",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<OdomPIDClient>(name, config, shared_self); }
    );

    factory.registerBuilder<InitializePortsActuators>(
        "InitializePortsActuators",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<InitializePortsActuators>(name, config, shared_self); }
    );

    factory.registerBuilder<WaitForSet>(
        "WaitForSet",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<WaitForSet>(name, config, shared_self); }
    );

    factory.registerBuilder<ZoneChange>(
        "ZoneChange",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<ZoneChange>(name, config, shared_self); }
    );

    factory.registerBuilder<SetDestinationFromPriority>(
        "SetDestinationFromPriority",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<SetDestinationFromPriority>(name, config, shared_self); }
    );

    factory.registerBuilder<GetLocationForStage>(
        "GetLocationForStage",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<GetLocationForStage>(name, config, shared_self); }
    );

    factory.registerBuilder<UpdateCurrentStage>(
        "UpdateCurrentStage",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<UpdateCurrentStage>(name, config, shared_self); }
    );

    factory.registerBuilder<CheckItemsPicked>(
        "CheckItemsPicked",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<CheckItemsPicked>(name, config, shared_self); }
    );

    factory.registerBuilder<BrakeTest>(
        "BrakeTest",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<BrakeTest>(name, config, shared_self); }
    );

    factory.registerBuilder<SetpointLoader>(
        "SetpointLoader",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<SetpointLoader>(name, config); }
    );

    factory.registerBuilder<DecisionOdom>(
        "DecisionOdom",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<DecisionOdom>(name, config, shared_self); }
    );

    factory.registerBuilder<DecisionSick>(
        "DecisionSick",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<DecisionSick>(name, config, shared_self); }
    );

    factory.registerBuilder<VelUntilLimit>(
        "VelUntilLimit",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<VelUntilLimit>(name, config, shared_self); }
    );

    factory.registerBuilder<GripperClose>(
        "GripperClose",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<GripperClose>(name, config, shared_self); }
    );

    factory.registerBuilder<GripperOpen>(
        "GripperOpen",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<GripperClose>(name, config, shared_self); }
    );

    factory.registerBuilder<MotorActuate>(
        "MotorActuate",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<MotorActuate>(name, config, shared_self); }
    );

    factory.registerBuilder<StallDetection>(
        "StallDetection",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<StallDetection>(name, config, shared_self); }
    );

}

// --- merged from bt.cpp ---
void tree_ticker::register_actions_nodes()
{
    auto shared_self = std::static_pointer_cast<tree_ticker>(this->shared_from_this());

    factory.registerBuilder<Climb>(
        "Climb",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<Climb>(name, config, shared_self); }
    );

    factory.registerBuilder<Roll>(
        "Roll",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<Roll>(name, config, shared_self); }
    );

    factory.registerBuilder<GripperPose>(
        "GripperPose",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<GripperPose>(name, config, shared_self); }
    );

    factory.registerBuilder<SetExtension>(
        "setExtension",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<SetExtension>(name, config, shared_self); }
    );

    factory.registerBuilder<SetHeight>(
        "setHeight",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<SetHeight>(name, config, shared_self); }
    );

    factory.registerBuilder<GripperAct>(
        "GripperAct",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<GripperAct>(name, config, shared_self); }
    );

    factory.registerBuilder<VelPublish>(
        "VelPublish",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<VelPublish>(name, config, shared_self); }
    );
}

void tree_ticker::register_decision_nodes()
{
    auto shared_self = std::static_pointer_cast<tree_ticker>(this->shared_from_this());

    factory.registerBuilder<PlanPath>(
        "PlanPath",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<PlanPath>(name, config, shared_self); }
    );

    factory.registerBuilder<DecisionNode>(
        "DecisionNode",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<DecisionNode>(name, config, shared_self); }
    );

    factory.registerBuilder<NodeAnalysis>(
        "NodeAnalysis",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<NodeAnalysis>(name, config, shared_self); }
    );

    factory.registerBuilder<bt_nodes::ArenaDecisionNode>(
        "ArenaDecisionNode",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<bt_nodes::ArenaDecisionNode>(name, config, shared_self); }
    );
}

void tree_ticker::register_condition_nodes()
{
    auto shared_self = std::static_pointer_cast<tree_ticker>(this->shared_from_this());

    factory.registerBuilder<isInsideForest>(
        "IsInsideForest",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<isInsideForest>(name, config, shared_self); }
    );

    factory.registerBuilder<CheckForC>(
        "CheckforC",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<CheckForC>(name, config, shared_self); }
    );

    factory.registerBuilder<CheckForS>(
        "CheckforS",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<CheckForS>(name, config, shared_self); }
    );

    factory.registerBuilder<CheckForProx>(
        "CheckForProx",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<CheckForProx>(name, config, shared_self); }
    );

    factory.registerBuilder<AlwaysNode>(
        "AlwaysNode",
        [shared_self](const std::string &name, const BT::NodeConfig &config)
        { return std::make_unique<AlwaysNode>(name, config, shared_self); }
    );
}

void tree_ticker::update_behavior_tree()
{
    bool debug_mode = this->get_parameter("debug").as_bool();
    auto status = debug_mode ? tree_.tickOnce() : tree_.tickWhileRunning();
    if(status != BT::NodeStatus::RUNNING)
    {
        RCLCPP_INFO(
            get_logger(),
            "Behavior Tree finished with status %d",
            static_cast<int>(status)
        );
        timer_->cancel();
    }
}

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<tree_ticker>("tree_ticker");

    rclcpp::executors::MultiThreadedExecutor executor;
    executor.add_node(node);

    node->setup();
    executor.spin();

    rclcpp::shutdown();
    return 0;
}